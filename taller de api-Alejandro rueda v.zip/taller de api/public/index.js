var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { getCharacters } from './services/characters.js';
console.log("hola");
class AppContainer extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
    }
    connectedCallback() {
        return __awaiter(this, void 0, void 0, function* () {
            const charactes = yield getCharacters();
            this.render(charactes);
        });
    }
    render(charactes) {
        if (!this.shadowRoot)
            return;
        const personajes = charactes.map(({ id, image, gender, name, species, status, type, url }) => `<article>
    <h3>${id}</h3>
    <img src="${image}">
    <h3>${gender}</h3>
    <h3>${name}</h3>
    <h3>${species}</h3>
    <h3>${status}</h3>
    <h3>${type}</h3>
    <h3>${url}</h3>
    </article>`);
        this.shadowRoot.innerHTML = `<section>
    ${personajes.join("")}
    
    
    </section>`;
    }
}
customElements.define("app-container", AppContainer);
