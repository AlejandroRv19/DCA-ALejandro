export interface Character {

    
    gender: string;
    id: number;
    image: string;

    name : string;
    species:  string;
    status: string;
    type: string;
    url: string;
}