
import { getCharacters} from './services/characters.js'
import { Character } from './types/index.js';

console.log("hola")

class AppContainer extends HTMLElement {

    constructor() {

        super();
        this.attachShadow({ mode: "open"});
        
         }

         async connectedCallback () {
            const charactes = await getCharacters();
            this.render(charactes);
         }


    render (charactes: Array<Character>) {
    if (!this.shadowRoot)return;



    const personajes = charactes.map(({id,image, gender, name, species, status, type, url}) => `<article>
    <h3>${id}</h3>
    <img src="${image}">
    <h3>${gender}</h3>
    <h3>${name}</h3>
    <h3>${species}</h3>
    <h3>${status}</h3>
    <h3>${type}</h3>
    <h3>${url}</h3>
    </article>` );
    this.shadowRoot.innerHTML = `<section>
    ${personajes.join("")}
    
    
    </section>`;
 }
}



customElements.define("app-container" , AppContainer);