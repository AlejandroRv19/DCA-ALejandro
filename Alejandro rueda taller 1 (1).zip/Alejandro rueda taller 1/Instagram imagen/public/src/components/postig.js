class Poster extends HTMLElement {
    constructor(){
        super()
        this.attachShadow({mode: 'open'})
    }
    connectedCallback(){
        this.render()
    }

    render(){
        this.shadowRoot.innerHTML = `
        <link rel ="stylesheet" href="/src/styles/styles.css">
        <div id="Caja1">
        <div id="cajon">
            <div id="Arriba">
                <div class="usuario">
                    <div class="perfil">
                        <img src="./src/image/Profile1.2.jpg" class="imagen1">
                    </div>
                    <h4>Kirby_2345</h4>
                </div>
                <div>
                    <img src="./src/image/punto.png" class="imagen2">
                </div>
            </div>
            <div class="imagen3">
                <img src="./src/image/chica.jfif" class="imagen32">
            </div>
            <div class="accion">
                <div class="left">
                    <img src="./src/image/corazon.png">
                    <img src="./src/image/comentario.png">
                    <img src="./src/image/compartir.png">
                </div>
                <div class="right">
                    <img src="./src/image/marca.png">
                </div>
            </div>
            <h3 class="gusta">101,120 Me gusta</h3>
            <h3 class="usuario2">Kirby_2345</h3>
        </div>
    </div>
        `
    }
}

customElements.define("main-box", Poster)
