// link de reserva por si no funicona normal
// "https://www.gstatic.com/firebasejs/9.11.0/firebase-app.js" iniciar aplicacion firebase
// "https://www.gstatic.com/firebasejs/8.10.1/firebase-firestore.js" iniciar, llamar y usar base de datos

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.11.0/firebase-app.js";

import { getFirestore, collection, addDoc, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.11.0/firebase-firestore.js";

// import { getFirestore, collection, addDoc, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.11.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyATW8Z6fsr-8ek3U1sdey_EVEpSt4Fg_k8",
  authDomain: "db-componets-ig.firebaseapp.com",
  projectId: "db-componets-ig",
  storageBucket: "db-componets-ig.appspot.com",
  messagingSenderId: "345162240378",
  appId: "1:345162240378:web:2c2c5343245a00e07f06c3"}

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const usersRef = collection(db, "usuarios");

// añadir un usuario a la base de datos
export const addUser = async ({ name, username, email, password }: { name: string, username: string, email: string, password: string }) => {
  try {
    const docRef = await addDoc(collection(db, "usuarios"), {
      name,
      username,
      email,
      password
    });
    return true
  } catch (e) {
    return false
  }
}

// buscar un usuario en la base de datos
export const queryUser = async ({ email, password }: { email: string, password: string }) => {
  try {
    const q1 = query(usersRef, where("email", "==", email))
    const q2 = query(usersRef, where("password", "==", password))

    const querySnapshot = await getDocs(q1 && q2);
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      console.log(doc.id, " => ", doc.data());
    });
  } catch (e) {
    return false
  }
}
